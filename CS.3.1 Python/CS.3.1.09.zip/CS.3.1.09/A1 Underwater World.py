import pygame

#Start the game
pygame.init()
game_width = 1000
game_height = 650
screen = pygame.display.set_mode((game_width, game_height))
clock = pygame.time.Clock()
running = True

#Load the images
background_pic = pygame.image.load("./assets/Scene_A.png")
player_pic = pygame.image.load("./assets/fish01A.png")

#Player's variables
player_x = 50
player_y = 100
player_speed = 3
player_size = 50
player_facing_left = False

while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
            running = False

#Check if key pressed and Player movement
    keys = pygame.key.get_pressed()
    if keys[pygame.K_RIGHT]:
        player_facing_left = False
        player_x += player_speed
    if keys[pygame.K_LEFT]:
        player_facing_left = True
        player_x -= player_speed
    if keys[pygame.K_UP]:
        player_y -= player_speed
    if keys[pygame.K_DOWN]:
        player_y += player_speed
    if keys[pygame.K_SPACE]:
        player_size += 2

    screen.blit(background_pic,(0,0))

    #draw the player
    player_pic_small = pygame.transform.scale(player_pic,(player_size,player_size))
    if player_facing_left:
        player_pic_small = pygame.transform.flip(player_pic_small,True,False)

    screen.blit(player_pic_small,(player_x, player_y))

    pygame.display.flip()
    clock.tick(50)
    pygame.display.set_caption("MY GAME fps: " + str(clock.get_fps()))

