import pygame

import alienProjectile
import aliens
import random
import misc
import player
import playerProjectile

# Start the game
pygame.init()
screen = pygame.display.set_mode((misc.game_width, misc.game_height))
clock = pygame.time.Clock()
running = True


# Load the background image
background_pic = pygame.transform.scale(pygame.image.load("./assets/background.png"),(misc.game_width,misc.game_height))

# Create the player object
player = player.Player(misc.game_width/2, 600)

# Player projectile variables
allPlayerProj = []
projectile_timer = 0
projectile_timer_max = 60
player_ammo = 10
projectile_duplicate = 5

# Initialise gamestate
gamestate = 'play'

# Alien object
alien = aliens.Alien(100,0,2)

# Alien variables
alien_timer = 0
allAliens = []

# Alien projectile variable
allAlienProj = []
alienProj_timer = random.randint(50, 200)

# Player health
health = 300

# Main game loop below
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
            running = False

    # Shoot the player projectile when the spacebar is pressed
    projectile_timer += 1
    keys = pygame.key.get_pressed()
    if keys[pygame.K_SPACE] and player_ammo > 0 and projectile_duplicate > 5:
        allPlayerProj.append(playerProjectile.Projectile(player.x, player.y))
        player_ammo -= 1
        projectile_duplicate = 0
    projectile_duplicate += 1

    # Reload ammo
    projectile_timer += 1
    if projectile_timer >= projectile_timer_max and player_ammo < 10:
        player_ammo += 1
        projectile_timer = 0

    # Draw the background, aliens, player and projectiles
    screen.blit(background_pic, (0,0))
    player.update(screen)

    for index in range(len(allAliens)-1, -1, -1):
        # Randomly create alien projectiles
        alien = allAliens[index]
        if alienProj_timer <= 0:
            allAlienProj.append(alienProjectile.Projectile(alien.x, alien.y))
            alienProj_timer = random.randint(50, 150)
        else:
            alienProj_timer -= 1

        # Check for collision between player projectiles and aliens
        for projectile in allPlayerProj:
            if projectile.hitbox.colliderect(alien.hitbox):
                alien.health -= 1
                allPlayerProj.remove(projectile)
            if alien.health <= 0:
                allAliens.remove(alien)
                break
        # Check if game is lost
        if alien.y > 500 or health <= 0:
            gamestate = 'end'

        # Check for collision between alien projectiles and player
        for projectile in allAlienProj:
            if projectile.hitbox.colliderect(player.hitbox):
                allAlienProj.remove(projectile)
                health -= 30

    # Remove projectiles that are out of the screen
    for index in range(len(allAlienProj), 0, -1):
        alienproj = allAlienProj[index - 1]
        if alienproj.y > misc.game_height:
            allAlienProj.remove(alienproj)
        alienproj.update(screen)

    # Remove projectiles that are out of the screen
    for index in range(len(allPlayerProj), 0, -1):
        playerproj = allPlayerProj[index - 1]
        if playerproj.y < 0 - playerproj.height:
            allPlayerProj.remove(playerproj)
        playerproj.update(screen)

    # When the game is in play
    if gamestate is 'play':
        # Randomly create new aliens over time
        if alien_timer <= 0:
            alien_timer = random.randint(50,150)
            allAliens.append(aliens.Alien(random.randint(200,750),0, 2))
        else:
            alien_timer -= 1
        for alien in allAliens:
            # Update all aliens
            alien.update(screen)

    # Update the game display
    pygame.display.flip()
    clock.tick(50)
    pygame.display.set_caption("MY GAME fps: " + str(clock.get_fps()))




