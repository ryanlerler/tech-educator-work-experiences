# Create the aliens class
import pygame
import random
import misc


# Aliens class
class Alien:
    def __init__(self, x, y, health):
        self.width = 100
        self.height = 100
        self.speed = 5
        self.x = x
        self.y = y
        self.pic_right = pygame.transform.scale(pygame.image.load("./assets/monsterRight.png"), (self.width, self.height))
        self.pic_left = pygame.transform.scale(pygame.image.load("./assets/monsterLeft.png"), (self.width, self.height))
        self.dir = 'left' if random.randint(0,1) == 1 else 'right'
        self.health = health
        self.hitbox = pygame.Rect(self.x, self.y, self.width, self.height)

    def update(self, screen):
        # Check if alien has touched the edge of the screen, then change direction
        if self.x >= misc.game_width - self.width:
            self.dir = 'left'
            self.y += self.height
        elif self.x <= 0:
            self.dir = 'right'
            self.y += self.height

        # Move alien to the right it is facing the right, else face left
        if self.dir is 'right':
            self.x += self.speed
            screen.blit(self.pic_right, (self.x, self.y))
        else:
            self.x -= self.speed
            screen.blit(self.pic_left, (self.x, self.y))

        # Update hitbox
        self.hitbox = misc.hitbox(self.hitbox, self.x, self.y)

