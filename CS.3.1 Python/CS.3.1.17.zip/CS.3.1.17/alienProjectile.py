# Space game
import pygame
import misc

# Alien Projectile class
class Projectile:
    def __init__(self, x, y):
        self.width = 60
        self.height = 120
        self.speed = 10
        self.x = x
        self.y = y
        self.pic = pygame.transform.scale(pygame.image.load("./assets/bulletMonster.png"),(self.width, self.height))
        self.hitbox = pygame.Rect(self.x, self.y, self.width, self.height)

    def update(self, screen):
        self.y += self.speed
        screen.blit(self.pic, (self.x, self.y))
        # Update hitbox
        self.hitbox = misc.hitbox(self.hitbox, self.x, self.y)

