class Student:

    def __init__(self, name, mark):
        self.name = name
        self.mark = mark

    def description(self):
        return "{} scored {} marks".format(self.name, self.mark)

    def code(self, language):
        return "{} codes in {}".format(self.name, language)

student1 = Student("Tom", 85)
student2 = Student("Jerry", 100)

print(student1.description())
print(student2.code("Python"))