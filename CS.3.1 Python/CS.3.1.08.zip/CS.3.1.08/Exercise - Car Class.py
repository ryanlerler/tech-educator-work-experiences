class Car:

    def __init__(self, make, model, bodyPaint, horsepower, price):
        self.make = make
        self.model = model
        self.bodyPaint = bodyPaint
        self.horsepower = horsepower
        self.price = price

    def info(self, country):
        return "Born in {}, I am a {} {} painted in {}, delivering a maximum horsepower of {}hp."\
            .format(country, self.make, self.model, self.bodyPaint, self.horsepower) #Backslash is not compulsory
# A backslash at the end of a line tells Python to extend the current logical line over across to the next physical line.

    def pricing(self):
        print("I'm currently priced at S$", self.price, "in Singapore")

    #Alternative:
    #def pricing(self): # Do not name the function "price" as it is an int variable as initialized
        #return "I'm currently priced at S$ {} in Singapore".format(self.price)
    #def pricing(self):
        #print("I'm currently priced at S$ {} in Singapore".format(self.price))

car1 = Car ("Toyota", "Camry 2.0", "Cherry Red", 164, 150000)
car2 = Car ("BMW", "330i", "Metallic Blue", 258, 220000)
car3 = Car ("Audi", "A4 Quattro", "Glacier White", 252, 230000)

print(car1.info("Japan"))
print(car2.info("Germany"))
print(car3.info("Germany"))

car1.pricing()
car2.pricing()
car3.pricing()

# Alternative (if return was used instead of print):
#print(car1.pricing())
#print(car2.pricing())
#print(car3.pricing())