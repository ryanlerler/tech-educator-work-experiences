#Parent class
class Dog:

    # Initializer/ Instance attributes
    def __init__(self, name, age):
        self.name = name
        self.age = age

    # instance method
    def description(self):
        print("{} is {} years old".format(self.name, self.age))

# Child class (inherits from Dog class)
class RussellTerrier(Dog):
    def run(self, speed):
        print("{} runs {}".format(self.name, speed))

# Child class (inherits from Dog class)
class Bulldog(Dog):
    def run(self, speed):
        print("{} runs {}".format(self.name, speed))

#Child classes inherit attributes and behaviours from the parent class
dog1 = RussellTerrier("Jim", 5)
dog1.description()

dog2= Bulldog("Johny",4)
dog2.description()

#Child class have specific attributes and behaviours as well
dog1.run("slowly")
dog2.run("fast")

# Is Jim an instance of Dog()?
print(isinstance(dog1, Dog))

# Is Julie an instance of Dog()?
Julie = Dog("Julie", 100)
print(isinstance(Julie, Dog))

# Is Johnywalker an instance of Bulldog()?
Johnywalker = RussellTerrier("Johnywalker", 4)
print(isinstance(Johnywalker, Bulldog))
# Is Johnywalker an instance of RussellTerrier()?
print(isinstance(Johnywalker, RussellTerrier))