# Question 1

from turtle import *
# no module name 'turtle' needed in front
# codes are shorter
forward(100)

import turtle
# module name 'turtle' needed in front
# codes are longer
turtle.forward(100)

# Question 2
y = 97 // 4
# 97 divided by 4 gives a quotient of 24
# y == 24
if y % 3 > 0:
    print("Hello")
else:
    print("There!")
# Since 24 / 3 = 8, remainder != >0 and == 0, "There!" will be printed.

# Question 3
list1 = [[0, 0, 0], 0, [0, 0], [0, 0, 0, [8, 0]]]
print(list1[3][3][0])

# Question 4
def greet(name):
    print("Hello " + name + "!")
greet("Ryan")

# Question 5
class Person:
    def __init__(self, name, age, fav_food):
        self.name = name
        self.age = age
        self.fav_food = fav_food
p1 = Person("Ryan", 28, "Chicken")

