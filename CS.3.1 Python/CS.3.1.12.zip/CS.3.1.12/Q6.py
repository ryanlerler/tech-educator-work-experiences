user_input = input("Enter a letter (use lower case letter 'a' to 'z' only): ")

if user_input == 'a' or user_input == 'e' or user_input == 'i' or user_input == 'o' or user_input == 'u':
    print(user_input, "is a vowel")
else:
    print(user_input, "is not a vowel")
