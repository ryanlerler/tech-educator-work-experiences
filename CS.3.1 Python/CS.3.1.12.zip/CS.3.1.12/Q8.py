list1 = [1, 3, 5, 7, 9]
list2 = [2, 4, 6, 8, 10]

combined = []

for i in range(len(list1)):
    combined.append(list1[i])
    combined.append(list2[i])

print(combined)