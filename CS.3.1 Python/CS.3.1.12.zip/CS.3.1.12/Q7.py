user_input = input("Enter a word: ")

if len(user_input) <3:
    print(user_input)
elif user_input[-3:] == "ing":
    print(user_input + "ly")
else:
    print(user_input + "ing")