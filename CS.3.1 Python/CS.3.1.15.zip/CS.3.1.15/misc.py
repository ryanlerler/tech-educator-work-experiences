# Store game variables and common functions to be used across all modules
game_width = 1280
game_height = 720


# Update hitbox
def hitbox(rect, x, y):
    rect.x, rect.y = x, y
    return rect

