import pygame
import misc
import player
import playerProjectile

# Start the game
pygame.init()
screen = pygame.display.set_mode((misc.game_width, misc.game_height))
clock = pygame.time.Clock()
running = True


# Load the background image
background_pic = pygame.transform.scale(pygame.image.load("./assets/background.png"),(misc.game_width,misc.game_height))

# Create the player object
player = player.Player(misc.game_width/2, 600)

# Player projectile variables
allPlayerProj = []
projectile_timer = 0
projectile_timer_max = 60
player_ammo = 10
projectile_duplicate = 5

# Main game loop below
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
            running = False

    # Shoot the player projectile when the spacebar is pressed
    projectile_timer += 1
    keys = pygame.key.get_pressed()
    if keys[pygame.K_SPACE] and player_ammo > 0 and projectile_duplicate > 5:
        allPlayerProj.append(playerProjectile.Projectile(player.x, player.y))
        player_ammo -= 1
        projectile_duplicate = 0
    projectile_duplicate += 1

    # Reload ammo
    projectile_timer += 1
    if projectile_timer >= projectile_timer_max and player_ammo < 10:
        player_ammo += 1
        projectile_timer = 0

    # Draw the background, aliens, player and projectiles
    screen.blit(background_pic, (0,0))
    player.update(screen)

    # Remove projectiles that are out of the screen
    for index in range(len(allPlayerProj), 0, -1):
        playerproj = allPlayerProj[index - 1]
        if playerproj.y < 0 - playerproj.height:
            allPlayerProj.remove(playerproj)
        playerproj.update(screen)

    # Update the game display
    pygame.display.flip()
    clock.tick(50)
    pygame.display.set_caption("MY GAME fps: " + str(clock.get_fps()))



