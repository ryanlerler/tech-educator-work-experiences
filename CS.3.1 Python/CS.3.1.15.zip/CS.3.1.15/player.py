import pygame
import misc


# Player class
class Player:
    def __init__(self, x, y):
        self.width = 100
        self.height = 100
        self.speed = 10
        self.x = x
        self.y = y
        self.dir = 'right'
        self.pic_right = pygame.transform.scale(pygame.image.load("./assets/tankRight.png"),(self.width, self.height))
        self.pic_left = pygame.transform.scale(pygame.image.load("./assets/tankLeft.png"),(self.width, self.height))
        self.hitbox = pygame.Rect(self.x, self.y, self.width, self.height)

    def update(self, screen):
        # Move the player when the keys are pressed, set direction to be the one it is facing
        keys = pygame.key.get_pressed()
        if keys[pygame.K_RIGHT]:
            self.x += self.speed
            self.dir = 'right'
        elif keys[pygame.K_LEFT]:
            self.x -= self.speed
            self.dir = 'left'

        # Set boundaries for player movement
        if self.x >= misc.game_width - self.width:
            self.x = misc.game_width - self.width
        elif self.x < 0:
            self.x = 0

        # Draw the correct image depending on the direction
        if self.dir is 'right':
            screen.blit(self.pic_right, (self.x, self.y))
        else:
            screen.blit(self.pic_left, (self.x, self.y))

        # Update hitbox
        self.hitbox = misc.hitbox(self.hitbox, self.x, self.y)
