name = ['t', 'i', 'm', 'o', 't', 'h', 'y']
name.sort()
print(name)


