array2d.append([13, 14, 15, 16])

for i in range(len(array2d)):
    array2d[i].append(20)
print(array2d)
