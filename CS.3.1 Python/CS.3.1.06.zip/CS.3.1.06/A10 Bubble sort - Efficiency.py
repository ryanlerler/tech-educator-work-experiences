toSort = [4, 2, 1, 5, 3]

for i in range(len(toSort)):
    for j in range(0, len(toSort)-i-1):
        if toSort[j] > toSort[j + 1]:
            toSort[j], toSort[j + 1] = toSort[j + 1], toSort[j]

print(toSort)