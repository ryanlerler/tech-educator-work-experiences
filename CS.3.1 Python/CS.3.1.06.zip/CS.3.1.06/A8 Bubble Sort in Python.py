toSort = [4, 2, 1, 5, 3]

for i in range(len(toSort)):
    for j in range(0, len(toSort)-1):
        if toSort[j] > toSort[j + 1]:
            bigger = toSort[j]
            smaller = toSort[j + 1]
            toSort[j]= smaller
            toSort[j + 1] = bigger
print(toSort)
