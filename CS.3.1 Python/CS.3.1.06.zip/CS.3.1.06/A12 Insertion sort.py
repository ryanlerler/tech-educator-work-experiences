toSort = [4, 2, 1, 5, 3]

for i in range(1, len(toSort)):
    key = toSort[i]
    j = i - 1

    # Compare key with each element on the left of it until an element smaller than it is found
    while j >= 0 and key < toSort[j]:
        print(key, toSort[j])
        toSort[j + 1] = toSort[j]
        j -= 1

    # Place key at after the element just smaller than it.
    toSort[j + 1] = key
print(toSort)
