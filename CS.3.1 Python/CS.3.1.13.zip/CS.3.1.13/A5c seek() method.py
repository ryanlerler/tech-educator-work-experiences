f = open('python.txt','r')

print(f.readline())
f.seek(22)
print(f.read(8))

f.close()