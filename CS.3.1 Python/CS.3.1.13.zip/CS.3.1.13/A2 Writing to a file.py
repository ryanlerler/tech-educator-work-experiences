f = open('python.txt', 'w')

f.write("Hello Roboto!")

f.close()