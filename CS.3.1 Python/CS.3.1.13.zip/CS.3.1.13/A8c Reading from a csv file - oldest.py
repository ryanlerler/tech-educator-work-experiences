import csv

csvfile = open('data.csv','r')
csvdict = csv.DictReader(csvfile)

ages = []

for row in csvdict:
    ages.append(row['age'])

print(max(ages))
csvfile.close()

