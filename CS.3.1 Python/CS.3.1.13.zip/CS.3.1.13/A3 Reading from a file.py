f = open('python.txt', 'r')

print(f.read())

f.close()