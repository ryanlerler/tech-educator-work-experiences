from random import choice

f = open('dictionary.txt', 'r')
f = f.read().split('\n')

word = choice(f)

life = 5
guess = []

while life > 0 and set(guess) != set(word):
    for letter in word:
        if letter in guess:
            print(letter + '', end = "")
        else:
            print("_", end = "")
    print("\nYou have", life, "life left")
    letter_guess = input("Choose a letter: ")
    if letter_guess not in word:
        life -= 1
    else:
        guess.append((letter_guess))
print("The word is " + word)