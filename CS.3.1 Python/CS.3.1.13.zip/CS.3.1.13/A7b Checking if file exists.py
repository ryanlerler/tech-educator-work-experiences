import os

existOrNot = os.path.exists('python.txt')
print(existOrNot)