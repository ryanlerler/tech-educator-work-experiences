f = open('python.txt', 'a')

f.write('\nI love Roboto!')

f.close()