import csv

csvfile = open('data.csv','r')
csvdict = csv.DictReader(csvfile)

for row in csvdict:
    print(row)
csvfile.close()

