import csv

csvfile = open('data.csv','r')

for row in csvfile:
    print(row, end = '')
csvfile.close()

