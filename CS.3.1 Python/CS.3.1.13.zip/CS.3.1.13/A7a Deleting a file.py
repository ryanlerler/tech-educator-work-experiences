import os

os.remove('python.txt')
