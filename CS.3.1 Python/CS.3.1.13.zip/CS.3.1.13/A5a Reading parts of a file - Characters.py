f = open('python.txt', 'r')

print(f.read(5))

f.close()