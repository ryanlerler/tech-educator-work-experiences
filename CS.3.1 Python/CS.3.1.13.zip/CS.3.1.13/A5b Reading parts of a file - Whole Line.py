f = open('python.txt', 'r')

print(f.readline())

f.close()