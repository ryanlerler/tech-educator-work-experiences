def greet():
    print("Hello Titus")

greet()