def greet(name):
    print("Hello " + name)

greet("Titus")