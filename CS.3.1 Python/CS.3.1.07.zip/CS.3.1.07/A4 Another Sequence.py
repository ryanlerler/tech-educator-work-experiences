def seq(n):
    if n <= 0:
        return 0
    elif n % 2 == 0:
        return 1 + seq(n/2)
    else:
        return 1 + seq(n-1)
print(seq(10))