def add(num1, num2):
    return num1 + num2

def minus(num1, num2):
    return num1 - num2

def multiply(num1,num2):
    return num1 * num2

def divide(num1, num2):
    return num1 / num2

entered = input("Enter the operation (use numbers, +, -, *, / and space only: )")
input_list = entered.split(" ")

if input_list[1] == "+":
    calculated = add
elif input_list[1] == "-":
    calculated = minus
elif input_list[1] == "*":
    calculated = multiply
elif input_list[1] == "/":
    calculated = divide

print(calculated(int(input_list[0]),int(input_list[2])))