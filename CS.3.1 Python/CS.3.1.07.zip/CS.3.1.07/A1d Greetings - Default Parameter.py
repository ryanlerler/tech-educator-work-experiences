def greet(name ="Titus"):
    print("Hello " + name)

greet()